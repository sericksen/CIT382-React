import React from "react";
import ReactDOM from "react-dom";
import { Stage, Layer, Star, Text } from "react-konva";
import Konva from "konva";

export default class Stars extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  handleDragStart = e => {
    e.target.setAttrs({
      shadowOffset: {
        x: 15,
        y: 15
      },
      scaleX: 1.1,
      scaleY: 1.1
    });
  };
  handleDragEnd = e => {
    e.target.to({
      duration: 0.5,
      easing: Konva.Easings.ElasticEaseOut,
      scaleX: 1,
      scaleY: 1,
      shadowOffsetX: 5,
      shadowOffsetY: 5
    });
  };

  handleStarClick = e => {
    console.log(JSON.stringify(e.target.getAttrs()));
  };

  render() {
    const text = "Try to drag a star...";
    const count = parseInt(this.props.count);
    return (
      <React.Fragment>
        <Stage width={window.innerWidth} height={window.innerHeight}>
          <Layer>
            <Text text={text} />
            {[...Array(count)].map(i => (
              <Star
                key={i}
                x={Math.random() * window.innerWidth}
                y={Math.random() * window.innerHeight}
                numPoints={5}
                innerRadius={20}
                outerRadius={40}
                fill={Konva.Util.getRandomColor()}
                opacity={0.8}
                rotation={Math.random() * 180}
                shadowColor="black"
                shadowBlur={10}
                shadowOpacity={0.6}
                draggable
                onDragStart={this.handleDragStart}
                onDragEnd={this.handleDragEnd}
                onClick={this.handleStarClick}
              />
            ))}
          </Layer>
        </Stage>
      </React.Fragment>
    );
  }
}
