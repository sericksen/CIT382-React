import React from "react";
import GChart from "./gChart.js";
import Tracker from './tracker.js';

function TrackCheck(props){
  if(props.track=== true){
    return <Tracker grab={props.grab}/>;
  } else {
    return null;
  }
 }

export default class WeatherPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {main:{
      zip: "",
      country: "",
      track: false
    }};

    //this.updateState=this.updateState.bind(this);
    this.handleLocation=this.handleLocation.bind(this);
    this.onChange=this.onChange.bind(this);
    this.handleTemp = this.handleTemp.bind(this);
    this.tracker=this.tracker.bind(this);
    console.log(this.props.data);
  }

  onChange(event){

    let code = event.target.value;
    let id = event.target.id;

    if(id === "zip"){
      this.setState({zip:code});
    } else if (id === "country") {
      this.setState({country:code});
    }

  }

  tracker(event){
      const checkBox = event.target;
      if (checkBox.checked === true){
      console.log("tracking");
      this.setState({track:true});
      } else {
      this.setState({track:false});
      }
  }

  handleTemp(event){
    let id = event.target.id;
    this.props.measure(id);
  }

  handleLocation(){
    // update this state with input values
    const { zip,country } = this.state;
    const info = {zip,country };
    console.log(info);
    this.props.passBack(info);
    
  }
  //this is for the location request
  
  render() {
    console.log("your props are "+ this.props.tempMod);
    const props = this.props.tempMod.length;
    const one = props-3;
    const two = props -2;
    const three= props -1;
    
    return (
      <div>
        <h2>[ Get a current weather report ]</h2>
        <table className="input">
          <tbody>
          <tr>
            <td>Zip:</td>
            <td>
              <input 
              type="text" 
              id="zip" 
              value={this.state.zip} 
              onChange={this.onChange}/>
            </td>
          </tr>
          <tr>
            <td >Country Code:</td>
            <td>
              <input 
              type="text" 
              id="country" 
              value={this.state.country} 
              onChange={this.onChange}/>
            </td>
          </tr>
          </tbody>
        </table>
        <form>
          <input type="radio" id="imp" name='measure' onClick={this.handleTemp}/> Imperial &nbsp;
          <input type="radio" id="met" name='measure' onClick={this.handleTemp}/> Metric &nbsp;
          <input type="radio" id="sta" name='measure' onClick={this.handleTemp}/> Standard &nbsp;
        </form>
        <br />
        <input type="checkbox" id="tracker" onClick={this.tracker}/> Track
        <div id="trackComponent"><TrackCheck track={this.state.track} grab={this.props.grab}/></div>
        <br />
        <br />
        <button onClick={this.handleLocation}>Get Weather</button>
        <br />
        <h3> Current weather conditions for {this.props.data.name} </h3>
        <table className="output">
          <tbody>
          <tr>
            <td>Temperature:</td>
            <td>{this.props.tempMod[one]}</td>
          </tr>
          <tr>
            <td>Pressure: </td>
            <td>{this.props.data.main.pressure}</td>
          </tr>
          <tr>
            <td>Humidity:</td>
            <td>{this.props.data.main.humidity}%</td>
          </tr>
          <tr>
            <td>Min.Temperature: </td>
            <td>{this.props.tempMod[two]}</td>
          </tr>
          <tr>
            <td>Max.Temperature:</td>
            <td>{this.props.tempMod[three]}</td>
          </tr>
          <tr>
            <td>Wind: </td>
            <td>{this.props.data.speed}mph at {this.props.data.wind.deg} degrees</td>
          </tr>
          <tr>
            <td>Weather Conditions:</td>
            <td>{this.props.data.weather[0].description}</td>
          </tr>
          </tbody>
        </table>
        <div className="ouput">
          <GChart className="output" tempMod={this.props.tempMod}/>
        </div>
      </div>
    );
  }
}
