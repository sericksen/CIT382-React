import React from "react";
import WeatherPage from "./weatherPage.js";

export default class GetWeather extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        "coord": {
          "lon": -123.1,
          "lat": 44.05
        },
        "weather": [
          {
            "id": 801,
            "main": "Clouds",
            "description": "loading...",
            "icon": "02n"
          }
        ],
        "base": "stations",
        "main": {
          "temp": "loading...",
          "pressure": "loading...",
          "humidity": "loading...",
          "temp_min": "loading...",
          "temp_max": "loading..."
        },
        "visibility": 16093,
        "wind": {
          "speed": "loading...",
          "deg": "",
          "gust": 11.8
        },
        "clouds": {
          "all": 20
        },
        "dt": 1552269540,
        "sys": {
          "type": 1,
          "id": 4018,
          "message": 0.0057,
          "country": "US",
          "sunrise": 1552314713,
          "sunset": 1552356813
        },
        "id": 420029689,
        "name": "Eugene",
        "cod": 200
      }, 
      api: {
        "zip":97403,
        "country":"us" },

      "firstURL":"http://api.openweathermap.org/data/2.5/weather?zip=",
      "secondURL":"&appid=ae281726e71b0a07a3bc5c518a5f7ba8&units=standard",
      "tempMod": []
    };

    this.passBack = this.passBack.bind(this);
    this.temperatureConverter= this.temperatureConverter.bind(this);
    this.tempUpdate= this.tempUpdate.bind(this);
    this.grab= this.grab.bind(this);

  }
  
  // CALLBACK FUNCTION PASSED DOWN TO CHILD COMPONENT TO UPDATE STATE BASED ON USER INPUT VALUES
  passBack(array){
    const {zip,country}= array;
    console.log("the passback array is "+ zip + ","+ country);
    console.log(this.state.api);
    let api = this.state.api;
  
    // UPDATE THE API WITH NEW ZIP AND COUNTRY CODE
    if(zip === undefined){
      api.country = array.country;
      console.log("country updated with " + api.country );
      this.setState({ api });
    } else if (country === undefined){
      api.zip = array.zip;
      console.log("zip updated with " + api.zip);
      this.setState({ api });
    } else {
      console.log("api updated with " + api[0]+ "," +api[1]);
      this.setState({ api: array });
    }

    this.grab();
   
  }

    // INITIAL PAGE LOAD OF DEFAULT LOCATION
  componentDidMount() {
    let api= this.state.firstURL+this.state.api.zip+","+this.state.api.country+this.state.secondURL;
    console.log(this.state.api);
    fetch(api)
      .then(response => 
        {
        let value = response.json();
        let status= response.status;
        console.log(status);
        return value;
        }
      )
      .then(data => {
        this.setState({data})
        this.tempUpdate();
    });
  }

  // move this down to child component. calculations based on that state and pass it back up to update mainstate
  
  temperatureConverter(array, measure){
    let output = array;
    if(measure === "met") {
      output = array.map( element => 
         Math.round((element-273.15))
        ); 
      console.log(output);
      return output;   

    } else if(measure === "sta") {

      output = array.map( element => 
        Math.round(((element-273.15)*1.8)+32)
        );
      console.log(output);
      return output;
    } else {
      output = array;
    }
      return output;
  }
  
  tempUpdate(id) {
    const measure = id;

    //KELVIN TO FAHRENHEIT
    let input = this.state.data;
    
    let [temp1, temp2, temp3 ] = [input.main.temp, input.main.temp_min,input.main.temp_max];
    let array = [temp1, temp2, temp3];

    const tempMod = this.state.tempMod.slice();
    const output = this.temperatureConverter(array, measure);

    for(let i=0; i< output.length; i++){
      tempMod.push(output[i]);
    }

    console.log(this.state.data.main);
    console.log(tempMod);

    this.setState({tempMod:tempMod});
  }
  
  grab(){
    let api = this.state.api;
    api = this.state.firstURL+this.state.api.zip+","+this.state.api.country+this.state.secondURL;
    console.log(this.state.api);
    fetch(api)
      .then(response => 
        {
        let value = response.json();
        let status= response.status;
        console.log(status);
        return value;
        }
      )
      .then(data => {
        this.setState({data})
        this.tempUpdate();
    });
  }
  render() {
    
    return <WeatherPage data={this.state.data} 
    tempMod={this.state.tempMod} 
    passBack={this.passBack} 
    measure={this.tempUpdate} 
    grab={this.grab}/>
  }
}
