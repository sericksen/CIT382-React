import React from "react";
import { Chart } from "react-google-charts";

export default class GChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      temp:[
        ["x", "weather"],
        [0, 0],
        [1, 10],
        [2, 23],
        [3, 17],
        [4, 18],
        [5, 9],
        [6, 11],
        [7, 27],
        [8, 33],
        [9, 40],
        [10, 32],
        [11, 35]
      ]
    };
    this.plot=this.plot.bind(this);
  }

  plot(){
    const props = this.props.tempMod.length;
    let tempMod = this.props.tempMod;
    let temp = this.state.temp.slice();

    
      let y= [];
      for(let i=0; i<= props;i+3){
      y.push(tempMod[i]);
      }
    
      let x=[];
      for(let j =0; j<=props; j++){
        x.push([j,y[j]]);
      }
      
    
      console.log("your arrays are " + x);
   temp.push(x);
   this.setState({temp});
}

  render() {
    return (
      <div>
      <button onClick={this.plot}>Plot that shit!</button>
      <Chart
        width={"600px"}
        height={"400px"}
        chartType="LineChart"
        loader={<div>Loading Chart</div>}
        data={this.state.temp}
        options={{
          hAxis: {
            title: "Time"
          },
          vAxis: {
            title: "Popularity"
          }
        }}
        rootProps={{ "data-testid": "1" }}
      />
      </div>
    );
  }
}
