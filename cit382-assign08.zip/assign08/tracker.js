import React from 'react';

export default class Tracker extends React.Component {
constructor(props){
    super(props);
    this.state= {
        data:[]
    }
  }

  componentDidMount(){
        console.log("tracking component loaded...");
        this.timerID = setInterval(
          () => this.props.grab(),
          1000
        );
  }
  componentWillUnmount() {
    clearInterval(this.timerID);
  }
  render(){
    return  <h2>Tracking ...</h2>
  }
}