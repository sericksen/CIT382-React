// Default values of Thing object
const defaultThing = {
  hands: 0,
  feet: 0,
  color: "",
  alive: true
};

class Thing {
  // Object initialization, may also declare to accept
  // parameters, where xxx || checks if parameters were provided
  // Only initialize parameters that were provided
  // ES6 also supports default parameters (hands = 0, ...)
  constructor(hands, feet, color, alive) {
    this.hands = hands || defaultThing.hands;
    this.feet = feet || defaultThing.feet;
    this.color = color || defaultThing.color;
    this.alive = alive || defaultThing.alive;
  }
  isAlive() {
    return this.alive;
  }
}

class Things {
  constructor(thing) {
    this.things = [];
    // Make sure we only add a Thing object to internal things array
    if (thing && typeof thing === "object" && thing instanceof Thing) {
      this.things.push(thing);
    }
  }
  add(thing) {
    if (thing && typeof thing === "object" && thing instanceof Thing) {
      this.things.push(thing);
    }
  }
  length() {
    return this.things.length;
  }
  clear() {
    this.things = [];
  }
}
